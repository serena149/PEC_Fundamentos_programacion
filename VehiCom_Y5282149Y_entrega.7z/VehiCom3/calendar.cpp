/*====================================================
El modulo calendar incluye los subprogramas
relacionados con el calendario. Se intenta
reutilizar, donde posible, el c�digo de la tercera
pr�ctica.
====================================================*/

#include <stdio.h>
#include <string.h>
#include "calendar.h"
#include "data_mgmt.h"

int calendar_blankSpaces2 = 12;
months monthsArray;
int calendarWidth = 27;

/*--crea el array de meses para el calendario --*/
void InitMonthsArray() {
  strcpy(monthsArray[0], "Enero");
  strcpy(monthsArray[1], "Febrero");
  strcpy(monthsArray[2], "Marzo");
  strcpy(monthsArray[3], "Abril");
  strcpy(monthsArray[4], "Mayo");
  strcpy(monthsArray[5], "Junio");
  strcpy(monthsArray[6], "Julio");
  strcpy(monthsArray[7], "Agosto");
  strcpy(monthsArray[8], "Septiembre");
  strcpy(monthsArray[9], "Octubre");
  strcpy(monthsArray[10], "Noviembre");
  strcpy(monthsArray[11], "Diciembre");
}

/*--busqueda de a�os bisiestos--*/
bool IsLeapYear(int aa){
  bool bool1;
  if(aa%100 != 0 || (aa%100 == 0 && aa%400 == 0)) {
    if(aa%4 == 0) {
      bool1 = true;
      return bool1;
      } else {
        bool1 = false;
        return bool1;
        }
    } else {
      bool1 = false;
      return bool1;
      }
  }

/*--determina n�mero de d�as por cada mes--*/
int DaysInMonth(int month, int aa){
  int days = 0;
  if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10|| month == 12) {
    days = 31;
    return days;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
    days = 30;
    return days;
    } else {
      if(IsLeapYear(aa)){
        days = 29;
        return days;
        } else{
        days = 28;
        return days;
        }
    }
  }

/*--calcula total de dias desde el 1/1/2000 hasta el 1 del mes que se imprimir� a pantalla--*/
int TotalDays(int month, int aa){
  int days = 0;
  int aux = 0;

  for(int i = 2000; i < aa; i++){
    if(IsLeapYear(i)){
      days = days + 366;
      } else {
        days = days + 365;
        }
    }
  for(int i = 1; i < month; i++){
    aux = DaysInMonth(i, aa);
    days = days + aux;
    }
  return days;
  }

/*--calcular primer d�a semana--*/
int FirstDayOfMonth(int days){
  int indexDayOfWeek = 0;
  indexDayOfWeek = ((days + 5) % 7);
  return indexDayOfWeek;
  }

/*--imprime los espacios y puntos antes del primer dia del mes--*/
void FirstCalendarLine(int dayOfWeek){
  PrintSpaces(calendar_blankSpaces2);
  if(dayOfWeek > 0){
    printf("    ");

    if(dayOfWeek <= 4) {
      for(int i = 1; i < dayOfWeek; i++){
        printf("    ");
        }
    } else {
      for(int i = 1; i <= 3; i++){
        printf("    ");
        }
      printf("   | ");
      if(dayOfWeek == 6){
        printf("    ");
        }
    }
  }
}

/*--imprime caracteres o numeros apropiados--*/
void PrintCharOrNumber(int i, int month, int aa, int customerId){
  TipoTripleBool tripleBool1;
  tripleBool1.usedBike = false;
  tripleBool1.usedScooter = false;
  tripleBool1.usedCar = false;

  tripleBool1 = VehicleStatsPerDay(i, month, aa, customerId);

  if(tripleBool1.usedBike == false && tripleBool1.usedScooter == false && tripleBool1.usedCar == false){
    printf("%2d", i);
    } else if (tripleBool1.usedBike == true && tripleBool1.usedScooter == true && tripleBool1.usedCar == true){
      printf("TO");
    } else if (tripleBool1.usedBike == true && tripleBool1.usedScooter == false && tripleBool1.usedCar == true){
      printf("BC");
    } else if (tripleBool1.usedBike == true && tripleBool1.usedScooter == true && tripleBool1.usedCar == false){
      printf("BP");
    } else if (tripleBool1.usedBike == false && tripleBool1.usedScooter == true && tripleBool1.usedCar == true){
      printf("CP");
    } else if (tripleBool1.usedBike == true && tripleBool1.usedScooter == false && tripleBool1.usedCar == false){
      printf(" B");
    } else if (tripleBool1.usedBike == false && tripleBool1.usedScooter == true && tripleBool1.usedCar == false){
      printf(" P");
    } else if (tripleBool1.usedBike == false && tripleBool1.usedScooter == false && tripleBool1.usedCar == true){
      printf(" C");
    }
  }

/*--maneja la estructura del resto del calendario--*/
void PrintCalendarNumbers(int dayOfWeek, int daysOfMonth, int customerId, int month, int aa){
  for(int i = 1; i <= daysOfMonth; i++){
    if (dayOfWeek == 4){
      PrintCharOrNumber(i, month, aa, customerId);
      printf(" | ");
      dayOfWeek = dayOfWeek+1;
      } else if (dayOfWeek == 6){
        PrintCharOrNumber(i, month, aa, customerId);
        printf("\n");
        PrintSpaces(calendar_blankSpaces2);
        dayOfWeek = 0;
      } else {
        PrintCharOrNumber(i, month, aa, customerId);
        printf("  ");
        dayOfWeek = dayOfWeek+1;
      }
    }
    printf("\n");
  }

/*--bucle de impresi�n de espacios--*/
void PrintSpaces(int spaces){
  for(int i = 0; i < spaces; i++){
    printf(" ");
    }
  }

/*--subprograma completo de impresi�n del calendario--*/
void PrintCalendar(int customerId, int month, int aa){
  int totalDays = 0;
  int firstDayIndex = 0;
  int lastDayIndex = 0;
  int daysInMonth = 0;

  if(aa >= 2000 && aa <= 2099){
    printf("\n");
    PrintSpaces(calendar_blankSpaces2);
    printf("%s", monthsArray[month - 1]);
    PrintSpaces(calendarWidth - strlen(monthsArray[month - 1]) - 4);
    printf("%4d\n", aa);
    PrintSpaces(calendar_blankSpaces2);
    printf("___________________________\n");
    PrintSpaces(calendar_blankSpaces2);
    printf(" L   M   M   J   V |  S   D\n");
    PrintSpaces(calendar_blankSpaces2);
    printf("                   |       \n");

    totalDays = TotalDays(month, aa);
    firstDayIndex = FirstDayOfMonth(totalDays);
    daysInMonth = DaysInMonth(month, aa);

    FirstCalendarLine(firstDayIndex);
    PrintCalendarNumbers(firstDayIndex, daysInMonth, customerId, month, aa);
    }
  }
