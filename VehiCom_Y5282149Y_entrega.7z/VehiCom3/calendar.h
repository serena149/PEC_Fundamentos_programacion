/*====================================================
El modulo calendar incluye los subprogramas
relacionados con el calendario. Se intenta
reutilizar, donde posible, el c�digo de la tercera
pr�ctica.
====================================================*/

#pragma once

#include "data_mgmt.h"

typedef char string[100];

typedef string months[12];

void InitMonthsArray();

bool IsLeapYear(int aa);

int DaysInMonth(int month, int aa);

int TotalDays(int month, int aa);

int FirstDayOfMonth(int days);

void PrintCharOrNumber(int i, int month, int aa, int customerId);

void PrintCalendarNumbers(int dayOfWeek, int daysOfMonth, int customerId, int month, int aa);

void PrintSpaces(int spaces);

void PrintCalendar(int customerId, int month, int aa);
