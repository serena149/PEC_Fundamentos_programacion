/*====================================================
El modulo print_to_console incluye los subprogramas
relacionados con lo que se muestra a consola.
====================================================*/

#include <stdio.h>
#include <string.h>
#include "data_mgmt.h"
#include "print_to_console.h"
#include "calendar.h"

int blankSpaces = 4;
int blankSpaces2 = 12;
int lineLength = 24;
int columnWidth = 20;

/*--impresion de linea tipo primera pantalla--*/
void PrintLine(int tab, int length, string str1, string str2){
  int aux = 0;
  while(tab > 0) {
    printf(" ");
    tab--;
    }
  printf("%s", str1);
  aux = length - strlen(str1);
  while(aux > 0) {
    printf(" ");
    aux--;
    }
  printf("%s\n", str2);
  }

/*--impresion de linea tipo pantalla nuevo cliente--*/
void PrintLine2(int tab, string str1){
  while(tab > 0) {
    printf(" ");
    tab--;
    }
  printf("%s", str1);
  }

/*--texto de la pantalla de alta nuevo cliente--*/
char NewCustomerText(){
  int id;
  string newName;
  string newSurname;
  char char1;
  char char2;
  printf("\nAlta nuevo cliente:\n\n");
  PrintLine2(blankSpaces, "Identificador (numero entre 1 y 50)?");
  fflush(stdin);
  scanf("%2d", &id);
  PrintLine2(blankSpaces, "Nombre (entre 1 y 10 caracteres)?");
  fflush(stdin);
  scanf("%[^\n]", &newName);
  PrintLine2(blankSpaces, "Apellido (entre 1 y 20 caracteres)?");
  fflush(stdin);
  scanf("%[^\n]", &newSurname);
  printf("\nDatos correctos (S/N)?");
  fflush(stdin);
  scanf("%c",&char1);
  printf("Otro cliente (S/N)?");
  fflush(stdin);
  scanf("%c",&char2);
  if(char1 == 'S'){
    UpdateCustomerTable(id, newName, newSurname);
    }
  return char2;
  }

/*--texto de la pantalla de alta nuevo veh�culo--*/
char NewVehicleText(){
  int id;
  char vehicleType;
  string description;
  float radius;
  float angle;
  char char1;
  char char2;
  printf("\nAlta nuevo vehiculo:\n\n");
  PrintLine2(blankSpaces, "Identificador (numero entre 1 y 20)?");
  fflush(stdin);
  scanf("%2d", &id);
  PrintLine2(blankSpaces, "Tipo de vehiculo (C/B/P)?");
  fflush(stdin);
  scanf("%c", &vehicleType);
  PrintLine2(blankSpaces, "Descripcion (entre 1 y 20 caracteres)?");
  fflush(stdin);
  scanf("%[^\n]", &description);
  PrintLine2(blankSpaces, "Radio (hasta 1000 metros)?");
  fflush(stdin);
  scanf("%f", &radius);
  PrintLine2(blankSpaces, "Angulo (entre 0.00 y 360.00 grados)?");
  fflush(stdin);
  scanf("%f", &angle);
  printf("\nDatos correctos (S/N)?");
  fflush(stdin);
  scanf("%c",&char1);
  printf("Otro vehiculo (S/N)?");
  fflush(stdin);
  scanf("%c",&char2);
  if(char1 == 'S'){
    UpdateVehicleTable(id, vehicleType, description, radius, angle);
    }
  return char2;
  }

/*--cabecera tabla vehiculos disponibles--*/
void AvailableVehiclesTableHeader(){
  int auxSpaces;
  printf("\n");
  PrintLine2(blankSpaces2, "Vehiculos disponibles:\n");
  printf("\n");
  PrintLine2(blankSpaces, "Ref.");
  auxSpaces = columnWidth - strlen("Ref.");
  PrintLine2(auxSpaces, "Identificador");
  auxSpaces = columnWidth - strlen("Identificador");
  PrintLine2(auxSpaces, "Tipo");
  auxSpaces = columnWidth - strlen("Tipo");
  PrintLine2(auxSpaces, "Distancia");
  auxSpaces = columnWidth - strlen("Distancia");
  PrintLine2(auxSpaces, "Rumbo");
  auxSpaces = columnWidth - strlen("Rumbo");
}

/*--resto tabla vehiculos disponibles--*/
void AvailableVehiclesTableRow(TipoVehicleCustomerDistance vehicle1, int i) {
  string auxString;
  printf("\n");
  PrintLine2(blankSpaces, "");
  printf("%1d", i);
  PrintLine2((columnWidth - 1), "");
  printf("%2d", vehicle1.id);
  PrintLine2((columnWidth - 2), "");
  printf("%c", vehicle1.vehicleType);
  PrintLine2((columnWidth - 1), "");
  printf("%7.2f", vehicle1.distance);
  PrintLine2((columnWidth - 7), "");
  printf("%4.2f", vehicle1.vehicleCustomerAngle);
  }

/*--texto de la pantalla de activaci�n de veh�culo--*/
void ActivateVehicleText(){
  int inputId;
  float radius;
  float angle;
  char vehicleType;
  int hh;
  int min;
  int dd;
  int month;
  int aa;

  TipoVehicleCustomerDistance vehicle1;
  TipoVehicle vehicle2;
  char char1;
  int chosenVehicleRef;

  printf("\nActivar vehiculo:\n\n");
  PrintLine2(blankSpaces, "Identificador cliente?");
  fflush(stdin);
  scanf("%2d", &inputId);
  PrintLine2(blankSpaces, "Ubicacion cliente: Radio?");
  fflush(stdin);
  scanf("%f", &radius);
  PrintLine2(blankSpaces, "Ubicacion cliente: Angulo?");
  fflush(stdin);
  scanf("%f", &angle);
  PrintLine2(blankSpaces, "Tipo de vehiculo (C/B/P/T)?");
  fflush(stdin);
  scanf("%c", &vehicleType);
  PrintLine2(blankSpaces, "Fecha de activacion (DD/MM/AA)?");
  fflush(stdin);
  scanf("%2d/%2d/%2d", &dd, &month, &aa);
  PrintLine2(blankSpaces, "Hora de activacion (HH:MM)?");
  fflush(stdin);
  scanf("%2d:%2d", &hh, &min);
  AvailableVehiclesTableHeader();

  for (int i = 1; i <= 5; i++){
    vehicle1 = AvailableVehicles(i, vehicleType, radius, angle);
    AvailableVehiclesTableRow(vehicle1, i);
    }

  printf("\n\n");
  PrintLine2(blankSpaces, "Ref. vehiculo seleccionado?");
  fflush(stdin);
  scanf("%1d", &chosenVehicleRef);

  printf("\n");
  PrintLine2(blankSpaces2, "Datos del vehiculo seleccionado:\n");
  vehicle1 = VehicleDataFromRef(chosenVehicleRef);
  vehicle2 = VehicleDataFromRef2(vehicle1.id);

  printf("\n");
  PrintLine2(blankSpaces, "Identificador: ");
  printf("%d", vehicle1.id);
  printf("      Tipo: ");
  switch(vehicle1.vehicleType){
    case 'C':
      printf("Coche");
      break;
    case 'B':
      printf("Bicicleta");
      break;
    case 'P':
      printf("Patinete");
      break;
    default:
      printf("No se ha seleccionado un vehiculo valido");
  }
  printf("\n");
  PrintLine2(blankSpaces, "");
  printf("Descripcion: %s\n", vehicle2.description);
  PrintLine2(blankSpaces, "");
  printf("Distancia desde cliente: %7.2f metros\n", vehicle1.distance);
  PrintLine2(blankSpaces, "");
  printf("Rumbo desde cliente: %4.2f grados", vehicle1.vehicleCustomerAngle);

  printf("\n\n");
  PrintLine2(blankSpaces, "Datos correctos (S/N)?");
  fflush(stdin);
  scanf("%c",&char1);

  if(char1 == 'S'){
    SaveActivationData(vehicle1.id, inputId, hh, min, dd, month, aa);
    printf("\n");
    PrintLine2(blankSpaces, "");
    printf("El vehiculo con identificador: %d, ha sido ACTIVADO desde las %2d:%2d horas del dia %2d/%2d/%2d.", vehicle1.id, hh, min, dd, month, aa);
    }
  }

/*--texto de la pantalla de devoluci�n de veh�culo--*/
void ReturnVehicleText(){
  int vehicleId;
  float radius;
  float angle;
  int minutes;
  TipoActVehicle vehicle1;
  char char1;

  printf("\nDevolver vehiculo:\n\n");
  PrintLine2(blankSpaces, "Identificacion vehiculo?");
  fflush(stdin);
  scanf("%d",&vehicleId);
  PrintLine2(blankSpaces, "Nueva ubicacion vehiculo: radio?");
  fflush(stdin);
  scanf("%f",&radius);
  PrintLine2(blankSpaces, "Nueva ubicacion vehiculo: angulo?");
  fflush(stdin);
  scanf("%f",&angle);
  PrintLine2(blankSpaces, "Tiempo de uso (en minutos)?");
  fflush(stdin);
  scanf("%d",&minutes);

  printf("\n");
  PrintLine2(blankSpaces2, "Datos del vehiculo:\n\n");
  PrintLine2(blankSpaces, "Identificador: ");
  printf("%d      ", vehicleId);
  vehicle1 = VehicleDataFromRef3(vehicleId - 1);
  PrintLine2(blankSpaces, "Tipo: ");
  switch(vehicle1.vehicleType){
    case 'C':
      printf("Coche\n");
      break;
    case 'B':
      printf("Bicicleta\n");
      break;
    case 'P':
      printf("Patinete\n");
      break;
    default:
      printf("No se ha seleccionado un vehiculo valido\n");
  }
  PrintLine2(blankSpaces, "Descripcion: ");
  printf("%s\n", vehicle1.description);
  PrintLine2(blankSpaces, "Nueva ubicacion: radio = ");
  printf("%.2f metros\n", radius);
  PrintLine2(blankSpaces, "Nueva ubicacion: angulo = ");
  printf("%.2f grados\n", angle);

  printf("\n");
  PrintLine2(blankSpaces, "");
  printf("Datos correctos (S/N)?");
  fflush(stdin);
  scanf("%c",&char1);

  if(char1 == 'S'){
    SaveReturnData(vehicleId, minutes);
    printf("\n");
    PrintLine2(blankSpaces, "");
    printf("El vehiculo con identificador: %d, ha sido DEVUELTO despues de haber sido utilizado durante %d minutos.", vehicleId, minutes);
    }
  }

/*--texto de la pantalla de resumen--*/
char MonthlyStatsText(){
  int customerId;
  int month;
  int aa;
  TipoCustomer customer1;
  int bikeMinutes;
  int scooterMinutes;
  int carMinutes;
  char char1;

  printf("\nResumen mensual de cliente\n");
  printf("Identificador cliente?");
  fflush(stdin);
  scanf("%d", &customerId);
  printf("Seleccion Mes?");
  fflush(stdin);
  scanf("%d", &month);
  printf("Seleccion Anno (aaaa)?");
  fflush(stdin);
  scanf("%4d", &aa);

  customer1 = CustomerDataFromRef(customerId);
  printf("\n");
  PrintLine2(blankSpaces2, "");
  printf("Resumen uso cliente: %s %s\n", customer1.cName, customer1.cSurname);

  PrintCalendar(customerId, month, aa);

  bikeMinutes = MinutesPerMonth(customerId, 'B', month, aa);
  scooterMinutes = MinutesPerMonth(customerId, 'P', month, aa);
  carMinutes = MinutesPerMonth(customerId, 'C', month, aa);

  printf("\nTiempo de uso Bicicletas: %d minutos", bikeMinutes);
  printf("\nTiempo de uso Patinetes: %d minutos", scooterMinutes);
  printf("\nTiempo de uso Coches: %d minutos", carMinutes);
  printf("\n\nB: Bicicleta P: Patinete C: Coche TO: Todos");

  printf("\n\nMostrar otro mes (S/N)?");
  fflush(stdin);
  scanf("%c",&char1);
  return char1;
  }

/*--gesti�n de ejecucion de la pantalla de nuevo cliente--*/
void RepeatNewCustomer(char c){
  char char1;
  if(c == 'S') {
    char1 = NewCustomerText();
    RepeatNewCustomer(char1);
    }
  }

/*--gesti�n de ejecucion de la pantalla de nuevo cliente--*/
void RepeatNewVehicle(char c){
  char char1;
  if(c == 'S') {
    char1 = NewVehicleText();
    RepeatNewVehicle(char1);
    }
  }

/*--gesti�n de ejecucion de la pantalla de resumen--*/
void RepeatMonthlyStats(char c){
  char char1;
  if(c == 'S') {
    char1 = MonthlyStatsText();
    RepeatMonthlyStats(char1);
    }
  }

/*--subprograma completo de primera pantalla--*/
void FirstScreen(){
  char c;
  printf("Vehicom: Gestion de vehiculos compartidos\n");
  PrintLine(blankSpaces, lineLength, "Alta nuevo cliente", "(Pulsar C)");
  PrintLine(blankSpaces, lineLength, "Alta nuevo vehiculo", "(Pulsar V)");
  PrintLine(blankSpaces, lineLength, "Activar vehiculo", "(Pulsar A)");
  PrintLine(blankSpaces, lineLength, "Devolver vehiculo", "(Pulsar D)");
  PrintLine(blankSpaces, lineLength, "Resumen mensual", "(Pulsar R)");
  PrintLine(blankSpaces, lineLength, "Salir", "(Pulsar S)");
  printf("Teclear una opcion valida (C|V|A|D|R|S)?\n");
  fflush(stdin);
  scanf("%c", &c);

  switch (c){
    case 'C':
      AddNewCustomer();
      break;
    case 'V':
      AddNewVehicle();
      break;
    case 'A':
      ActivateVehicle();
      break;
    case 'D':
      ReturnVehicle();
      break;
    case 'R':
      MonthlyStats();
      break;
    default:
      ;
    }
  }

/*--subprograma completo de alta nuevo cliente--*/
void AddNewCustomer(){
  char char1;
  char1 = NewCustomerText();
  RepeatNewCustomer(char1);
  printf("\n\n");
  FirstScreen();
  }

/*--subprograma completo de alta nuevo veh�culo--*/
void AddNewVehicle(){
  char char1;
  char1 = NewVehicleText();
  RepeatNewVehicle(char1);
  printf("\n\n");
  FirstScreen();
  }

/*--subprograma completo de activaci�n de veh�culo--*/
void ActivateVehicle(){
  ActivateVehicleText();
  printf("\n\n");
  FirstScreen();
  }

/*--subprograma completo de devoluci�n de veh�culo--*/
void ReturnVehicle(){
  ReturnVehicleText();
  printf("\n\n");
  FirstScreen();
  }

/*--subprograma completo de resumen mensual--*/
void MonthlyStats(){
  char char1;
  char1 = MonthlyStatsText();
  RepeatMonthlyStats(char1);
  printf("\n\n");
  FirstScreen();
  }
