/*====================================================
El modulo print_to_console incluye los subprogramas
relacionados con lo que se muestra a consola.
====================================================*/

#pragma once

#include "data_mgmt.h"

void PrintLine(int tab, int length, string str1, string str2);

void PrintLine2(int tab, string str1);

char NewCustomerText();

char NewVehicleText();

void AvailableVehiclesTableHeader();

void AvailableVehiclesTableRow(TipoVehicleCustomerDistance vehicle1, int i);

void ActivateVehicleText();

void ReturnVehicleText();

char MonthlyStatsText();

void RepeatNewCustomer(char c);

void RepeatNewVehicle(char c);

void RepeatMonthlyStats(char c);

void FirstScreen();

void AddNewCustomer();

void AddNewVehicle();

void ActivateVehicle();

void ReturnVehicle();

void MonthlyStats();
