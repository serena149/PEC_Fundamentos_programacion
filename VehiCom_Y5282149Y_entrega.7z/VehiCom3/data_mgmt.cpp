/*====================================================
El modulo data_mgmt incluye los subprogramas
relacionados con datos y tablas.
====================================================*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "data_mgmt.h"

customerTable cTable;
vehicleTable vTable;
actVehicleTable avTable;
vehicleTableTemp vTableTemp;
cStatsTable csTable;

/*inicializaci�n de la tabla de datos de clientes*/
void InitCustomerTable(){
  for (int i = 0; i < 50; i++) {
    cTable[i].id = 0;
    strcpy(cTable[i].cName, "");
    strcpy(cTable[i].cSurname, "");
    }
  }

/*inicializaci�n de la tabla de datos de vehiculos*/
void InitVehicleTable(){
  for (int i = 0; i < 20; i++) {
    vTable[i].id = 0;
    vTable[i].vehicleType = 'N';
    strcpy(vTable[i].description, "");
    vTable[i].radius = 0.0;
    vTable[i].angle = 0.0;
    }
   }

/*inicializaci�n de la tabla de datos de vehiculos activados*/
void InitActVehicleTable(){
  for (int i = 0; i < 20; i++) {
    avTable[i].customerId = 0;
    avTable[i].vehicleId = 0;
    avTable[i].vehicleType = 'N';
    strcpy(avTable[i].description, "");
    avTable[i].radius = 0.0;
    avTable[i].angle = 0.0;
    }
  }

/*inicializaci�n de la tabla de datos de clientes*/
void InitCStatsTable(){
  for (int i = 0; i < 99; i++) {
    csTable[i].customerId = 0;
    csTable[i].minutes = 0;
    csTable[i].vehicleType = 'N';
    csTable[i].day = 0;
    csTable[i].month = 0;
    csTable[i].aa = 0;
    }
  }

/*Actualiza tabla de clientes*/
void UpdateCustomerTable(int id, string newName, string newSurname) {
  cTable[id-1].id = id;
  strcpy(cTable[id-1].cName, newName);
  strcpy(cTable[id-1].cSurname, newSurname);
  }

/*Actualiza tabla de vehiculos*/
void UpdateVehicleTable(int id, char vehicleType, string description, float radius, float angle) {
  vTable[id-1].id = id;
  vTable[id-1].vehicleType = vehicleType;
  strcpy(vTable[id-1].description, description);
  vTable[id-1].radius = radius;
  vTable[id-1].angle = angle;
  }

/*conversi�n radianes - angulos para las distancias de los coches*/
float DegreesToRadians(float degrees){
  return degrees * M_PI / 180.0;
  }

/*conversi�n angulos - radianes para las distancias de los coches*/
float RadiansToDegrees(float radians){
  return radians * 180.0 / M_PI;
  }

/*calculo de distancias en coordenadas polares*/
float PolarCoordDistance(float rho1, float rho2, float theta1, float theta2) {
  float result;
  theta1 = DegreesToRadians(theta1);
  theta2 = DegreesToRadians(theta2);
  result = pow(rho1, 2) + pow(rho2, 2) - 2*rho1*rho2*cos(theta1-theta2);
  if (result >= 0) {
    return sqrt(result);
    } else {
      return sqrt(-result);
      }
  }

/*busqueda de 5 vehiculos cercanos*/
TipoVehicleCustomerDistance AvailableVehicles(int index, char inputChar, float rho1, float theta1) {
  TipoVehicleCustomerDistance vehicle1;
  bool isAvailable = true;
  float distance1 = 999999999999999999.9;
  float distance2;

  vehicle1.id = 0;
  vehicle1.vehicleType = 'N';
  vehicle1.distance = 0.0;
  vehicle1.vehicleCustomerAngle = 0.0;

  for (int j = 0; j < 20; j++){
      for (int k = 0; k < 5; k++) {
        if(vTableTemp[k].id!= 0 && vTableTemp[k].id == vTable[j].id){
          isAvailable = false;
          }
        }
    if(isAvailable == true){
      if(vTable[j].id != 0){
          if(inputChar == 'T' || inputChar == vTable[j].vehicleType){
          distance2 = PolarCoordDistance(rho1, vTable[j].radius, theta1, vTable[j].angle);
            if(distance2 < distance1){
            distance1 = distance2;
            vehicle1.id = vTable[j].id;
            vehicle1.vehicleType = vTable[j].vehicleType;
            vehicle1.distance = distance1;
            vehicle1.vehicleCustomerAngle = (vTable[j].angle - theta1);
            }
          }
        }
      }
    isAvailable = true;
  }
  vTableTemp[index] = vehicle1;
  return vehicle1;
  }

/*--devuelve los datos de un veh�culo de vTableTemp*/
TipoVehicleCustomerDistance VehicleDataFromRef(int ref) {
  return vTableTemp[ref];
  }

/*--devuelve los datos de un veh�culo de vTable*/
TipoVehicle VehicleDataFromRef2(int ref){
  TipoVehicle vehicle1;
  int i = 0;
  while(i < 20){
      if (vTable[i].id == ref) {
        vehicle1 = vTable[i];
        return vehicle1;
      }
    i++;
  }
  vehicle1.id = 0;
  vehicle1.vehicleType = 'N';
  strcpy(vehicle1.description, "");
  vehicle1.angle = 0.0;
  vehicle1.radius = 0.0;
  return vehicle1;
 }

/*--devuelve los datos de un veh�culo de avTable*/
 TipoActVehicle VehicleDataFromRef3(int ref) {
  return avTable[ref];
  }

/*--devuelve los datos de un cliente de cTable*/
TipoCustomer CustomerDataFromRef(int ref){
  int i = 0;
  TipoCustomer customer1;
  while(i < 50){
    if(cTable[i].id == ref){
      return cTable[i];
    }
    i++;
    }
  customer1.id = 0;
  strcpy(customer1.cName, "");
  strcpy(customer1.cSurname, "");
  return customer1;
  }

/*--Guarda los datos del coche activado a la nueva tabla, los borra de la anterior--*/
void SaveActivationData(int index, int customerId, int hh, int min, int dd, int month, int aa) {
  int i = 0;

  avTable[index-1].customerId = customerId;
  avTable[index-1].vehicleId = vTable[index-1].id;
  avTable[index-1].vehicleType = vTable[index-1].vehicleType;
  strcpy(avTable[index-1].description, vTable[index-1].description);
  avTable[index-1].radius = vTable[index-1].radius;
  avTable[index-1].angle = vTable[index-1].angle;
  avTable[index-1].hh = hh;
  avTable[index-1].min = min;
  avTable[index-1].dd = dd;
  avTable[index-1].month = month;
  avTable[index-1].aa = aa;

  while(i < 20){
    if (vTable[i].id == index-1) {
      vTable[index-1].id = 0;
      vTable[index-1].vehicleType = 'N';
      strcpy(vTable[index-1].description, "");
      vTable[index-1].radius = 0.0;
      vTable[index-1].angle = 0.0;
      }
    i++;
    }
  i = 0;
  while (i <5){
    vTableTemp[i].id = 0;
    vTableTemp[i].vehicleType = 'N';
    vTableTemp[i].distance = 0.0;
    vTableTemp[i].vehicleCustomerAngle = 0.0;
    i++;
    }
  }

/*--Guarda los datos del coche devuelto a la nueva tabla, los borra de la anterior--*/
void SaveReturnData(int vehicleId, int minutes){
  int i = 0;
  int k = 0;
  bool canSaveData = true;

  while (k < 99){
      if(canSaveData == true) {
        if(csTable[k].customerId == 0){
          csTable[k].customerId = avTable[vehicleId-1].customerId;
          csTable[k].minutes = minutes;
          csTable[k].vehicleType = avTable[vehicleId-1].vehicleType;
          csTable[k].day = avTable[vehicleId-1].dd;
          csTable[k].month = avTable[vehicleId-1].month;
          csTable[k].aa = avTable[vehicleId-1].aa;
          canSaveData = false;
          }
      }
      k++;
    }

  vTable[vehicleId-1].id = vehicleId;
  vTable[vehicleId-1].vehicleType = avTable[vehicleId-1].vehicleType;
  strcpy(vTable[vehicleId-1].description, avTable[vehicleId-1].description);
  vTable[vehicleId-1].radius = avTable[vehicleId-1].radius;
  vTable[vehicleId-1].angle = avTable[vehicleId-1].angle;

  while(i < 20){
    if (vTable[i].id == vehicleId-1) {
      avTable[vehicleId-1].customerId = 0;
      avTable[vehicleId-1].vehicleId = 0;
      avTable[vehicleId-1].vehicleType = 'N';
      strcpy(avTable[vehicleId-1].description, "");
      avTable[vehicleId-1].radius = 0.0;
      avTable[vehicleId-1].angle = 0.0;
      avTable[vehicleId-1].hh  = 0;
      avTable[vehicleId-1].min  = 0;
      avTable[vehicleId-1].dd = 0;
      avTable[vehicleId-1].month = 0;
      avTable[vehicleId-1].aa = 0;
      }
    i++;
    }

  }

/*--suma los minutos de uso de un tipo de vehiculo en un mes concreto*/
int MinutesPerMonth(int customerId, char vehicleType, int month, int aa){
  int total = 0;
  for(int i = 0; i < 99; i++){
    if(csTable[i].customerId == customerId){
    if(csTable[i].vehicleType == vehicleType){
    if(csTable[i].month == month){
    if(csTable[i].aa == aa || csTable[i].aa == (aa - 2000)|| csTable[i].aa == (aa + 2000)){
        total = total + csTable[i].minutes;
    }
    }
    }
    }
    }
    return total;
  }

/*--devuelve un struct de 3 booleanos para determinar qu� vehiculos se han usado cada d�a del calendario --*/
TipoTripleBool VehicleStatsPerDay(int day, int month, int aa, int customerId){
  TipoTripleBool tripleBool1;
  tripleBool1.usedBike = false;
  tripleBool1.usedScooter = false;
  tripleBool1.usedCar = false;

  for(int i = 0; i < 99; i++){
    if(csTable[i].customerId == customerId){
    if(csTable[i].day == day && csTable[i].month == month){
    if(csTable[i].aa == aa || csTable[i].aa == (aa - 2000)|| csTable[i].aa == (aa + 2000)){
    if(csTable[i].vehicleType == 'B'){
      tripleBool1.usedBike = true;
    } else if(csTable[i].vehicleType == 'P'){
      tripleBool1.usedScooter = true;
    } else if(csTable[i].vehicleType == 'C'){
      tripleBool1.usedCar = true;
    }
    }
    }
    }
    }
  return tripleBool1;
  }
