/*====================================================
El modulo data_mgmt incluye los subprogramas
relacionados con datos y tablas.
====================================================*/

#pragma once

typedef char string[100];

typedef struct TipoCustomer {
  int id;
  string cName;
  string cSurname;
  };

typedef struct TipoVehicle {
  int id;
  char vehicleType;
  string description;
  float radius;
  float angle;
  };

typedef struct TipoVehicleCustomerDistance {
  int id;
  char vehicleType;
  float distance;
  float vehicleCustomerAngle;
  };

typedef struct TipoActVehicle {
  int customerId;
  int vehicleId;
  char vehicleType;
  string description;
  float radius;
  float angle;
  int hh;
  int min;
  int dd;
  int month;
  int aa;
  };

typedef struct TipoCustomerStat {
  int customerId;
  int minutes;
  char vehicleType;
  int day;
  int month;
  int aa;
  };

typedef struct TipoTripleBool{
  bool usedBike;
  bool usedScooter;
  bool usedCar;
  };

typedef TipoCustomer customerTable[50];

typedef TipoVehicle vehicleTable[20];

typedef TipoVehicleCustomerDistance vehicleTableTemp[5];

typedef TipoActVehicle actVehicleTable[20];

typedef TipoCustomerStat cStatsTable[99];

void InitCustomerTable();

void InitVehicleTable();

void InitActVehicleTable();

void InitCStatsTable();

void UpdateCustomerTable(int id, string newName, string newSurname);

void UpdateVehicleTable(int id, char vehicleType, string description, float radius, float angle);

float DegreesToRadians(float degrees);

float RadiansToDegrees(float radians);

float PolarCoordDistance(float rho1, float rho2, float theta1, float theta2);

TipoVehicleCustomerDistance AvailableVehicles(int index, char inputChar, float rho1, float theta1);

TipoVehicleCustomerDistance VehicleDataFromRef(int ref);

TipoVehicle VehicleDataFromRef2(int ref);

TipoActVehicle VehicleDataFromRef3(int ref);

TipoCustomer CustomerDataFromRef(int ref);

void SaveActivationData(int index, int customerId, int hh, int min, int dd, int month, int aa);

void SaveReturnData(int vehicleId, int minutes);

int MinutesPerMonth(int customerId, char vehicleType, int month, int aa);

TipoTripleBool VehicleStatsPerDay(int day,int month, int aa, int customerId);
