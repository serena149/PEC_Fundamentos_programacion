/****************************************************
* NOMBRE: #Serena#
* PRIMER APELLIDO: #Lombardi#
* SEGUNDO APELLIDO: #---#
* DNI: #Y5282149Y#
* EMAIL: #slombardi6@alumno.uned.es#
******************************************************
El programa VehiCom gestiona el alquiler de hasta 20
vehiculos para 50 clientes
*****************************************************/

#include <stdio.h>
#include <math.h>
#include "print_to_console.h"
#include "data_mgmt.h"
#include "calendar.h"

/*====================================================
Programa principal
====================================================*/

char option;

int main (){
  InitCustomerTable();
  InitVehicleTable();
  InitActVehicleTable();
  InitCStatsTable();
  InitMonthsArray();
  FirstScreen();
  return 0;
  }
